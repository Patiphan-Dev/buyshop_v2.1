<div class="col-md-12 col-sm-12 mt-4" data-aos="zoom-in-down">
    <ol class="breadcrumb mt-3 crad_tung text-white">
        <li class="breadcrumb-item text-white hvr-shrink pointer" onclick="CradURL('./page/home')">หน้าแรก</li>
        <li class="breadcrumb-item text-white active">ฝากขายไอดีเกม</li>
    </ol>
</div>

<div class="col-md-12 col-sm-12 mt-2" data-aos="zoom-in-down">
    <div class="alert alert-dismissible alert-danger">
        <strong>แจ้งเตือน</strong> สำหรับผู้ใช้ที่ยืนยันตนแล้วเท่านั้นยัง ผู้ใช้ทั่วไปยังไม่เปิดให้บริการตอนนี้! <a href="page/shop" class="alert-link">ร้านค้า</a>.
    </div>
</div>
<!-- 
<div class="col-md-6 col-sm-12 mt-2" data-aos="zoom-in">
    <div class="card crad_tung text-white mb-3">
        <div class="card-header"><i class="fa-solid fa-money-bill-wheat" style="color:#F7B600;"></i> Deposit ID-Game - ฝากขายไอดีเกม</div>
        <div class="card-body">

            <div class="form-group mb-2">
                <label class="col-form-label" for="inputDefault"><i class="fa-solid fa-chevron-right"></i> ชื่อสินค้า</label>
                <input type="text" class="form-control" placeholder="รหัส COD เวล150" id="name">
            </div>
            <div class="form-group mb-2">
                <label class="col-form-label" for="inputDefault"><i class="fa-solid fa-chevron-right"></i> URL - รูปสินค้า <a href="https://th.imgbb.com" target="_blank" rel="noopener noreferrer">imgbb.com</a></label>
                <textarea id="urlshop" class="form-control" name="urlshop" rows="3" placeholder="https://i.ibb.co/N2wfyw5/750s-1.png"></textarea>
            </div>
            <div class="form-group mb-2">
                <label class="col-form-label" for="inputDefault"><i class="fa-solid fa-chevron-right"></i> ข้อมูลสินค้าแสดงหน้าเว็บ</label>
                <textarea id="urlshop" class="summernote" name="urlshop" rows="5" placeholder="https://i.ibb.co/N2wfyw5/750s-1.png"></textarea>
            </div>
            <div class="form-group mb-2">
                <label class="col-form-label" for="inputDefault"><i class="fa-solid fa-chevron-right"></i> ข้อมูลลับ <span class="badge rounded-pill bg-danger" style="font-size: 0.9rem;"> เห็นเฉพาะผู้ซื้อและผู้ขายเท่านั้น!!</span></label>
                <textarea id="urlshop" class="form-control" name="urlshop" rows="3" placeholder="ตัวอย่าง id:asdzxc123 pass:123465"></textarea>
            </div>
            <div class="form-group mb-2 mt-4">
                <div class="alert alert-dismissible alert-warning text-center">
                    <h4 class="alert-heading">ใช้ 10 เครดิต ในการฝากขาย!!</h4>
                    <p class="mb-0">หากต้องการเติมเครดิตให้ไปที่, <a href="?page=topup" class="alert-link">เติมเงิน</a>.</p>
                </div>
            </div>

            <div class="form-group mb-3 mt-4">
                <button onclick="login()" class="btn btn-primary w-100"><i class="fa-solid fa-circle-check"></i> ตรวจสอบข้อมูล</button>
            </div>


        </div>
    </div>
</div>


<div class="col-md-6 col-sm-12 mt-2" data-aos="zoom-in">
    <div class="card crad_tung text-white mb-3">
        <div class="card-header"><i class="fa-solid fa-box-open" style="color:#F186A9;"></i> History - ประวัติการฝากขายไอดี</div>
        <div class="card-body">


        </div>
    </div>
</div> -->